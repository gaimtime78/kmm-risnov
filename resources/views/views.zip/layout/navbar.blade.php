 <!-- START HEADER -->
 <header id="header" class="page-topbar">
        <!-- start header nav-->
        <div class="navbar-fixed">
            <nav class="navbar-color">
                <div class="nav-wrapper">
                    <ul class="left">                      
                      <li>
                        <h1 class="logo-wrapper">
                          <a href="index.htm" class="brand-logo darken-1">
                            <!-- <img src="" alt="IRIS1103"> -->
                            Biro RPM
                          </a> 
                          <span class="logo-text"></span>
                        </h1>
                      </li>
                    </ul>
                    <ul class="right hide-on-med-and-down">                     
                        <li><a href="{{route('home')}}" class="waves-effect waves-block waves-light"><i class="mdi-action-dashboard"></i></a>
                        </li>
                    </ul>
                    
                </div>
            </nav>
        </div>
        <!-- end header nav-->
    </header>
    <!-- END HEADER -->
